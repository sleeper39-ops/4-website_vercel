-- Custom Items Table
tbl_custom = {}
tbl_override = {}
