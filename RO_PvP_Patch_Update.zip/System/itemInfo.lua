-- ========================================================
-- RO Classic Pre-Renewal itemInfo Master Loader
-- Preserves Exact CP949 Resource Icons & CP874 Thai Text
-- ========================================================

local function SafeAddItem(id, unIdName, unIdRes, idName, idRes, slots, classNum)
	if not id or id <= 0 then return end
	unIdName = unIdName or ""
	unIdRes = unIdRes or ""
	idName = idName or unIdName or ("Item " .. id)
	idRes = idRes or unIdRes or ""
	slots = slots or 0
	classNum = classNum or 0
	
	local ok, res, msg = pcall(AddItem, id, unIdName, unIdRes, idName, idRes, slots, classNum)
	return ok and res
end

local function SafeAddUnidentifiedDesc(id, desc)
	if not id or id <= 0 or not desc then return end
	pcall(AddItemUnidentifiedDesc, id, tostring(desc))
end

local function SafeAddIdentifiedDesc(id, desc)
	if not id or id <= 0 or not desc then return end
	pcall(AddItemIdentifiedDesc, id, tostring(desc))
end

local function SafeAddEffectInfo(id, effectId)
	if not id or id <= 0 or not effectId then return end
	pcall(AddItemEffectInfo, id, effectId)
end

local function SafeAddIsCostume(id, isCostume)
	if not id or id <= 0 or isCostume == nil then return end
	pcall(AddItemIsCostume, id, isCostume)
end

local function SafeAddPackageID(id, pkgId)
	if not id or id <= 0 or not pkgId then return end
	pcall(AddItemPackageID, id, pkgId)
end

function main()
	if not tbl then return true, "good" end
	
	for ItemID, DESC in pairs(tbl) do
		if ItemID and ItemID > 0 and type(DESC) == "table" then
			SafeAddItem(ItemID, DESC.unidentifiedDisplayName, DESC.unidentifiedResourceName, DESC.identifiedDisplayName, DESC.identifiedResourceName, DESC.slotCount, DESC.ClassNum)
			
			if DESC.unidentifiedDescriptionName and type(DESC.unidentifiedDescriptionName) == "table" then
				for _, line in ipairs(DESC.unidentifiedDescriptionName) do
					SafeAddUnidentifiedDesc(ItemID, line)
				end
			end
			
			if DESC.identifiedDescriptionName and type(DESC.identifiedDescriptionName) == "table" then
				for _, line in ipairs(DESC.identifiedDescriptionName) do
					SafeAddIdentifiedDesc(ItemID, line)
				end
			end
			
			if DESC.EffectID then
				SafeAddEffectInfo(ItemID, DESC.EffectID)
			end
			
			if DESC.costume ~= nil then
				SafeAddIsCostume(ItemID, DESC.costume)
			end
			
			if DESC.PackageID then
				SafeAddPackageID(ItemID, DESC.PackageID)
			end
		end
	end
	return true, "good"
end

-- Initialize master table
tbl = tbl or {}

-- 1. Load Thai Item & Card Database
if not pcall(dofile, "SystemEN/itemInfo_TH.lua") then
	if not pcall(dofile, "System/itemInfo_TH.lua") then
		pcall(dofile, "itemInfo_TH.lua")
	end
end

-- 2. Load Custom Server Items (if any)
if not pcall(dofile, "SystemEN/itemInfo_C.lua") then
	if not pcall(dofile, "System/itemInfo_C.lua") then
		pcall(dofile, "itemInfo_C.lua")
	end
end

if tbl_custom then
	for k, v in pairs(tbl_custom) do
		tbl[k] = v
	end
end
if tbl_override then
	for k, v in pairs(tbl_override) do
		tbl[k] = v
	end
end
